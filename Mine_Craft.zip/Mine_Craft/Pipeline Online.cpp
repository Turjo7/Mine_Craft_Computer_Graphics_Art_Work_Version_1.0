#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <windows.h>
#include <glut.h>
#include <bits/stdc++.h>
using namespace std;



struct box
{
    int x_move,y_move,z_move;       //moving value to put in stack
    int x_scale,y_scale,z_scale;    //scaling value to put in stack
    int r_color,g_color,b_color;

    box()
    {

        x_move=0;
        y_move=0;
        z_move=0;
        x_scale=1;  //initial value which will be updated by value from new values
        y_scale=1;
        z_scale=1;
        r_color=0;
        g_color=0;
        b_color=0;
    }

};

stack <box> stora;
box saver;          //it has to be declared global to reach keyboard function also after structure box

//double cameraAngle;
double R, Rspeed, vAngle, hAngle, angleSpeed;
int move_x=0;
int move_y=0;       //where LEGOMAN is at right now
int move_z=0;



int x_index=0;
int y_index=0;      //which index of square he is in
int z_index=0;

int scale_x=0;
int scale_y=0;
int scale_z=0;







void StoreBrick()
{
    if(stora.empty())
    {
        return;
    }
    stack <box> draw;
    draw=stora;
    while(!draw.empty())
    {
        glTranslated(draw.top().x_move,draw.top().y_move,draw.top().z_move);    //always translate how far it is in
        glPushMatrix();
        glColor3f(draw.top().r_color,draw.top().g_color,draw.top().b_color);        //what color it is

        glScalef(draw.top().x_scale,draw.top().y_scale,draw.top().z_scale);      //scaling how big i want to make the box.
        glTranslatef(-5,-5,5);  //the box in 0,0,0 position.
        glutSolidCube(10);      //the box
        glTranslated(draw.top().x_move,draw.top().y_move,draw.top().z_move);    //always translate how far it is in
        glPopMatrix();
        glTranslated(-draw.top().x_move,-draw.top().y_move,-draw.top().z_move);    //reset back to originial position.
        draw.pop();
    }
}

void display()
{
	//codes for Models, Camera

	//clear the display
	//color black
	// The whole screen color
	glClearColor(0.54, 0.53, 0.53, 0);


	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);



	glMatrixMode(GL_MODELVIEW);

	glLoadIdentity();



	gluLookAt(0,0,100,	0,0,0,	0,1,0);

    {
        double x = sqrt(R*R+1);
        double y = atan(1.0/R);

        double a = x*cos(vAngle+y)*cos(hAngle)-R*cos(vAngle)*cos(hAngle);
        double b = x*cos(vAngle+y)*sin(hAngle)-R*cos(vAngle)*sin(hAngle);
        double c = x*sin(vAngle+y)-R*sin(vAngle);

        gluLookAt(move_x+R*cos(vAngle)*cos(hAngle),move_y+R*cos(vAngle)*sin(hAngle),move_z+R*sin(vAngle),  move_x,move_y,move_z,  a,b,c);
    }


	//again select MODEL-VIEW
	glMatrixMode(GL_MODELVIEW);



	// draw the three major AXES
	//drawAxis();

	//some grid lines along the field
	glPushMatrix();
	glTranslated(-95,-110,0);

    glPopMatrix();
         //  1   2




    glTranslated(0,0,5);


    glPushMatrix();
    glTranslated(0,-15,-5);

    glPopMatrix();




    glPushMatrix();
    StoreBrick();                           //it stores value here (gltranstated-er age korte hobe. jehetu already move_xyz ache)
    glPopMatrix();




    glTranslated(move_x,move_y,move_z);     //X

    glPushMatrix();

    glTranslated(5,-10,0);
    glTranslated(0,0,-5);
	glScalef(scale_x,scale_y,scale_z);      //scaling how big i want to make the box.
	glTranslatef(-5,-5,5);
	glutSolidCube(10);
	glPopMatrix();

















    glPushMatrix();
    glColor3f(0,0,0);
    glTranslated(0,5,60);       //head
    glutSolidCube(10);
    glPopMatrix();


    glPushMatrix();
    glColor3f(0,0.87,0.81);
    glTranslated(0,5,40);       //body
    glScalef(1,1,3);
    glScalef(3,1,1);
    glutSolidCube(10);
    glPopMatrix();


    glPushMatrix();
    glTranslated(10,0,0);

    glPushMatrix();
    glColor3f(0.57,0,0.82);
    glTranslated(0,5,15);
    glScalef(1,1,2);                //left leg  with left knee
    //glTranslatef(10,0,0);
    glutSolidCube(10);
    glPopMatrix();

    glColor3f(0.80,0.76,0.74);
    glScalef(1,2,1);
    glutSolidCube(10);




    glPushMatrix();
    glColor3f(0.62,0.32,0.17);

    glTranslated(10,0,40);
    //glRotatef(90.0, 0.0, 0.0, 1.0);

    glutSolidCube(10);
    glPopMatrix();      //left hand


    glPopMatrix();






    glPushMatrix();
    glColor3f(1,0,0);
    glTranslated(-10,0,0);

    glPushMatrix();
    glColor3f(0.57,0,0.82);
    glTranslated(0,5,15);
    glScalef(1,1,2);                //right leg with right knee
    //glTranslatef(10,0,0);
    glutSolidCube(10);
    glPopMatrix();

    glColor3f(0.80,0.76,0.74);
    glScalef(1,2,1);
    glutSolidCube(10);






    glPushMatrix();
    glColor3f(0.62,0.32,0.17);
    glTranslated(-10,0,40);
    //glRotatef(90.0, 0.0, 0.0, 1.0);
    glutSolidCube(10);
    glPopMatrix();      //right hand

    glPopMatrix();






	glutSwapBuffers();
}

void keyboardListener(unsigned char key, int x, int y)
{

}

void specialKeyListener(int key, int x, int y)
{
	if (key == GLUT_KEY_UP)
	{
		vAngle+=angleSpeed;

	}
	else if (key == GLUT_KEY_DOWN)
	{
		vAngle-=angleSpeed;
	}
	else if (key == GLUT_KEY_LEFT)
	{
		hAngle-=angleSpeed;
	}
	else if (key == GLUT_KEY_RIGHT)
	{
		hAngle+=angleSpeed;
	}
	else if (key == GLUT_KEY_PAGE_UP)
	{glRotatef(-45, 1,0,0);
	    if(R>=Rspeed){
            R-=Rspeed;
	    }
	}
	else if (key == GLUT_KEY_PAGE_DOWN)
    {
        R+=Rspeed;
    }
}

void animate()
{

	glutPostRedisplay();

}

void init()
{
	//codes for initialization

	//angle in radian
	//cameraAngle = 0;
	R = 100.0;
	Rspeed = 3.0;

	vAngle = 0.0;
    hAngle = 0.0;
    angleSpeed = 0.05;

	//clear the screen
	glClearColor(0, 0, 0, 0);





	//load the PROJECTION matrix
	glMatrixMode(GL_PROJECTION);

	//initialize the matrix
	glLoadIdentity();



	gluPerspective(70, 1, 0.1, 10000.0);

}

int main(int argc, char **argv)
{

	glutInit(&argc, argv);

	glutInitWindowSize(1000,1000);
	glutInitWindowPosition(50, 50);

	/*
	glutInitDisplayMode - inits display mode
	GLUT_DOUBLE - allows for display on the double buffer window
	GLUT_RGBA - shows color (Red, green, blue) and an alpha
	GLUT_DEPTH - allows for depth buffer
	*/
	glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGB);

	glutCreateWindow("ASSIGNMENT");

	//codes for initialization
	init();

	//enable Depth Testing
	glEnable(GL_DEPTH_TEST);

	//display callback function
	glutDisplayFunc(display);

	glutSpecialFunc(specialKeyListener);
	glutKeyboardFunc(keyboardListener);

	//what you want to do in the idle time (when no drawing is occuring)
	glutIdleFunc(animate);

	//The main loop of OpenGL
	glutMainLoop();

	return 0;
}
